package beiwanglu;
//创建备忘录管理角色草稿箱DraftBox类
import java.util.Stack;

public class DraftsBox {
private final Stack<ArticleMemento> STACK = new Stack<ArticleMemento>();
public ArticleMemento getMemento() {
ArticleMemento articleMemento = STACK.pop();//Stack栈类实现了后进先出的栈，pop()移除堆栈顶部对象，并作为此函数的值返回该对象
  return articleMemento;
}
public void addMemento(ArticleMemento articleMemento ) {
	STACK.push(articleMemento);//把对象压入堆栈顶部
}

public static void main(String[] args) {
	DraftsBox draftsBox = new DraftsBox();
	Editor editor = new Editor("设计模式之备忘录模式", "使用备忘录模式实现草稿箱功能", "放弃吧，穷，没图");
	ArticleMemento articleMemento = editor.saveToMemento();
	draftsBox.addMemento(articleMemento);
	System.out.println("标题："+ editor.getTitle()+ "\n"+"内容："+editor.getContent()+"\n"+"插图："+editor.getImgs()+"\n 暂存成功");
	System.out.println("文章完整的信息"+editor);
	
	System.out.println("===================首次修改文章=================================");
	editor.setTitle("老师我想过个好年，在这给您拜个早年谢谢了");
	editor.setContent("看在我恶补了好多东西的份上，分数不要太为难我QAQ");
	System.out.println("================================首次修改文章完成======================");
	
	System.out.println("文章完整信息"+editor);
	
	articleMemento = editor.saveToMemento();
	
	draftsBox.addMemento(articleMemento);
	
	System.out.println("================================已保存到草稿箱====================");
	
	System.out.println("===============================第二次修改文章========================");
	editor.setTitle("老师你看我还有机会吗");
	editor.setContent("上课都有好好听讲，至少平时分多给点TAT这话您要是不爱听我就撤回了当我没说");
	System.out.println("文章的完整信息"+editor);
	System.out.println("================================第二次修改文章完成======================");
	
	System.out.println("===============================第1次撤销========================");
	articleMemento = draftsBox.getMemento();
	editor.undoFromMemento(articleMemento);
	System.out.println("文章完整信息"+editor);
	System.out.println("================================第1次撤销完成======================");

System.out.println("===============================第2次撤销========================");
articleMemento = draftsBox.getMemento();
editor.undoFromMemento(articleMemento);
System.out.println("文章完整信息"+editor);
System.out.println("================================第2次撤销完成======================");
}
}

